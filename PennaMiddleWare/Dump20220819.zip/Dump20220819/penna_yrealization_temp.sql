-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: penna
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `yrealization_temp`
--

DROP TABLE IF EXISTS `yrealization_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `yrealization_temp` (
  `YREALIZATION_PKID` int NOT NULL AUTO_INCREMENT,
  `VBELN` varchar(10) NOT NULL,
  `VGBEL` varchar(10) NOT NULL,
  `AUBEL` varchar(10) NOT NULL,
  `ERDAT` varchar(10) NOT NULL,
  `FKART` varchar(4) NOT NULL,
  `REGIO` varchar(3) NOT NULL,
  `VKGRP` varchar(3) NOT NULL,
  `DSTRC` varchar(4) NOT NULL,
  `MNFPLANT` varchar(4) NOT NULL,
  `PLANT` varchar(4) NOT NULL,
  `GRADE` varchar(2) NOT NULL,
  `MATKL` varchar(9) NOT NULL,
  `KALKS` varchar(1) NOT NULL,
  `KDGRP` varchar(2) NOT NULL,
  `FKDAT` varchar(10) NOT NULL,
  `MATNR` varchar(18) NOT NULL,
  `CUSTCODE1` varchar(10) NOT NULL,
  `CNAME1` varchar(35) NOT NULL,
  `CUSTCODE2` varchar(10) NOT NULL,
  `CNAME2` varchar(35) NOT NULL,
  `CUSTCODE3` varchar(10) NOT NULL,
  `CNAME3` varchar(35) NOT NULL,
  `COM_AG` varchar(10) NOT NULL,
  `COM_NAME` varchar(35) NOT NULL,
  `TRANS` varchar(10) NOT NULL,
  `TRANS_NAME` varchar(35) NOT NULL,
  `LGORT` varchar(4) NOT NULL,
  `LGOBE` varchar(16) NOT NULL,
  `FKIMG` decimal(13,3) NOT NULL,
  `GROSSTURN` decimal(16,3) NOT NULL,
  `INCO1` varchar(3) NOT NULL,
  `INCO2` varchar(28) NOT NULL,
  `STPRS` decimal(12,3) NOT NULL,
  `PRIMARYFRI` decimal(16,3) NOT NULL,
  `SECONDARYFRI` decimal(16,3) NOT NULL,
  `EXWPF` decimal(16,3) NOT NULL,
  `EXGSF` decimal(16,3) NOT NULL,
  `SALESTAX` decimal(16,3) NOT NULL,
  `COMMISSION` decimal(16,3) NOT NULL,
  `EXCISEDUTY` decimal(16,3) NOT NULL,
  `PDDISCOUNT` decimal(16,3) NOT NULL,
  `ODDISCOUNT` decimal(16,3) NOT NULL,
  `CFCHARGES` decimal(16,3) NOT NULL,
  `CDDISCOUNT` decimal(16,3) NOT NULL,
  `PACKING` decimal(16,3) NOT NULL,
  `UNLOADING` decimal(16,3) NOT NULL,
  `OCTRAI` decimal(16,3) NOT NULL,
  `VAT` decimal(16,3) NOT NULL,
  `IGST` decimal(16,3) NOT NULL,
  `CGST` decimal(16,3) NOT NULL,
  `SGST` decimal(16,3) NOT NULL,
  `UGST` decimal(16,3) NOT NULL,
  `EXP_HAND` decimal(16,3) NOT NULL,
  `TRANSPORT` decimal(16,3) NOT NULL,
  `AMT_DW_FRT` decimal(16,3) NOT NULL,
  `PLT_FRT` decimal(16,3) NOT NULL,
  `NETTURN` decimal(16,3) NOT NULL,
  `NAKEDREAL` decimal(16,3) NOT NULL,
  `STATEDESC` varchar(20) NOT NULL,
  `SGRPDESC` varchar(20) NOT NULL,
  `DISDESC` varchar(20) NOT NULL,
  `GRADDESC` varchar(20) NOT NULL,
  `MNFDESC` varchar(30) NOT NULL,
  `PLANTDESC` varchar(30) NOT NULL,
  `PGRPDESC` varchar(20) NOT NULL,
  `CDATE` varchar(10) NOT NULL,
  `TIME` varchar(8) NOT NULL,
  `SUSER` varchar(12) NOT NULL,
  `BLOCK_CT` varchar(1) NOT NULL,
  `ROUTE` varchar(40) NOT NULL,
  `CANCELDATE` varchar(10) NOT NULL,
  `CANCELFLAG` varchar(1) NOT NULL,
  `ZZLGORT1` varchar(4) NOT NULL,
  `BZIRK` varchar(6) NOT NULL,
  `VKBUR` varchar(4) NOT NULL,
  `ZZZONE1` varchar(10) NOT NULL,
  `ZZBRANCH` varchar(4) NOT NULL,
  `PERNR_ER` varchar(8) NOT NULL,
  `ENAME_ER` varchar(40) NOT NULL,
  `PERNR_Y1` varchar(8) NOT NULL,
  `ENAME_Y1` varchar(40) NOT NULL,
  `PERNR_Y2` varchar(8) NOT NULL,
  `ENAME_Y2` varchar(40) NOT NULL,
  `PERNR_Y3` varchar(8) NOT NULL,
  `ENAME_Y3` varchar(40) NOT NULL,
  `PERNR_Y4` varchar(8) NOT NULL,
  `ENAME_Y4` varchar(40) NOT NULL,
  `PERNR_Y5` varchar(8) NOT NULL,
  `ENAME_Y5` varchar(40) NOT NULL,
  `PERNR_Y6` varchar(8) NOT NULL,
  `ENAME_Y6` varchar(40) NOT NULL,
  `PERNR_Y7` varchar(8) NOT NULL,
  `ENAME_Y7` varchar(40) NOT NULL,
  `PERNR_Y8` varchar(8) NOT NULL,
  `ENAME_Y8` varchar(40) NOT NULL,
  `UPFRNT_DISCOUNT` decimal(16,3) NOT NULL,
  `IND_PRI_FRT` decimal(16,3) NOT NULL,
  `SHIP_FRT_CHRGS` decimal(16,3) NOT NULL,
  `SHIP_HAND_CHRGS` decimal(16,3) NOT NULL,
  `ZCUST_GRP` varchar(2) NOT NULL,
  `ZCUST_GRP_DESC` varchar(20) NOT NULL,
  `Vc` decimal(12,3) NOT NULL,
  `ZsalePromValue` decimal(12,3) NOT NULL,
  `Waers` varchar(5) NOT NULL,
  `Msehi` varchar(3) NOT NULL,
  `PayFreight` decimal(14,3) NOT NULL,
  `ExFreight` decimal(14,3) NOT NULL,
  PRIMARY KEY (`YREALIZATION_PKID`),
  KEY `idx_yrealization_temp_VBELN` (`VBELN`)
) ENGINE=InnoDB AUTO_INCREMENT=23248 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  9:52:20
