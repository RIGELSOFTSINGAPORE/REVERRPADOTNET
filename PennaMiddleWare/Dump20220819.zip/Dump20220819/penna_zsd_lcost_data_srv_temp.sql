-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: penna
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `zsd_lcost_data_srv_temp`
--

DROP TABLE IF EXISTS `zsd_lcost_data_srv_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `zsd_lcost_data_srv_temp` (
  `ZSD_LCOST_DATA_SRV_PKID` int NOT NULL AUTO_INCREMENT,
  `VBELN` varchar(10) NOT NULL,
  `FKART` varchar(4) NOT NULL,
  `FKDAT` varchar(10) NOT NULL,
  `FKIMG` decimal(13,3) NOT NULL,
  `MEINS` varchar(3) NOT NULL,
  `WERKS` varchar(4) NOT NULL,
  `W_NAME1` varchar(30) NOT NULL,
  `ZSOURCE` varchar(2) NOT NULL,
  `ZSOURCED` varchar(60) NOT NULL,
  `ZTRATYP` varchar(2) NOT NULL,
  `ZTRATYPD` varchar(60) NOT NULL,
  `KUNNR` varchar(10) NOT NULL,
  `KUNNR_N` varchar(35) NOT NULL,
  `KUNAG` varchar(10) NOT NULL,
  `KUNAG_N` varchar(35) NOT NULL,
  `PTNR` varchar(10) NOT NULL,
  `PTNR_N` varchar(35) NOT NULL,
  `SALSREP` varchar(10) NOT NULL,
  `SALSREP_N` varchar(35) NOT NULL,
  `REGIO` varchar(3) NOT NULL,
  `REGIO_N` varchar(20) NOT NULL,
  `DSTRC` varchar(4) NOT NULL,
  `DSTRC_N` varchar(20) NOT NULL,
  `BLOCK` varchar(7) NOT NULL,
  `BLOCK_N` varchar(20) NOT NULL,
  `DESTINT` varchar(10) NOT NULL,
  `DESTINT_N` varchar(20) NOT NULL,
  `KDGRP` varchar(2) NOT NULL,
  `KTEXT` varchar(20) NOT NULL,
  `PRIMARY_FRT` decimal(14,3) NOT NULL,
  `SECONDRY_FRT` decimal(14,3) NOT NULL,
  `RAKNO` varchar(20) NOT NULL,
  `RAKPT` varchar(6) NOT NULL,
  `MATKL` varchar(9) NOT NULL,
  `LGORT` varchar(4) NOT NULL,
  `LGOBE` varchar(16) NOT NULL,
  `INCO1` varchar(3) NOT NULL,
  `INCO2` varchar(28) NOT NULL,
  `ULDG_CHGS` decimal(9,3) NOT NULL,
  `TRNS_CHGS` decimal(9,3) NOT NULL,
  `DPUL_CHGS` decimal(9,3) NOT NULL,
  `DPLD_CHGS` decimal(9,3) NOT NULL,
  `DIVR_CHGS` decimal(9,3) NOT NULL,
  `LDNG_CHGS` decimal(9,3) NOT NULL,
  `CFAG_CHGS` decimal(9,3) NOT NULL,
  `RKSR_CHGS` decimal(9,3) NOT NULL,
  `PULD_CHGS` decimal(9,3) NOT NULL,
  `RKCL_CHGS` decimal(9,3) NOT NULL,
  `SHNT_CHGS` decimal(9,3) NOT NULL,
  `RKCF_CHGS` decimal(9,3) NOT NULL,
  `BLND_CHGS` decimal(9,3) NOT NULL,
  `BLNB_CHGS` decimal(9,3) NOT NULL,
  `MISC_MISC` decimal(9,3) NOT NULL,
  `ZZZONE1` varchar(10) NOT NULL,
  `ZZZONE1_N` varchar(60) NOT NULL,
  `ZZBZIRK` varchar(6) NOT NULL,
  `ZZBZIRK_N` varchar(60) NOT NULL,
  `ZZREGIO` varchar(3) NOT NULL,
  `ZZREGIO_N` varchar(60) NOT NULL,
  `VKBUR` varchar(4) NOT NULL,
  `VKBUR_N` varchar(60) NOT NULL,
  `VKGRP` varchar(3) NOT NULL,
  `VKGRP_N` varchar(60) NOT NULL,
  `ZZBRANCH` varchar(4) NOT NULL,
  `ZZBRANCH_N` varchar(60) NOT NULL,
  `PDSTN` decimal(13,3) NOT NULL,
  `SDSTN` decimal(13,3) NOT NULL,
  `BLOCK_CT` varchar(1) NOT NULL,
  `BELNR` varchar(10) NOT NULL,
  `GJAHR` varchar(4) NOT NULL,
  `INV_TYPE` varchar(18) NOT NULL,
  `FRT_TYPE` varchar(12) NOT NULL,
  `ZZVLFKZ` varchar(1) NOT NULL,
  `SUPP_PLANT_NAME` varchar(30) NOT NULL,
  `DEPO_RK_MVT` varchar(20) NOT NULL,
  `IND_PRI_FRT` decimal(16,3) NOT NULL,
  `SHIP_FRT_CHRGS` decimal(16,3) NOT NULL,
  `SHIP_HAND_CHRGS` decimal(16,3) NOT NULL,
  `CLKMNFPLANT` varchar(4) NOT NULL,
  `SUPPPLANT` varchar(4) NOT NULL,
  `DISTANCE` decimal(7,2) NOT NULL,
  `INDPDISTANCE` decimal(7,2) NOT NULL,
  `CLK_PLT_NAME` varchar(30) NOT NULL,
  `MNF_PLT_NAME` varchar(30) NOT NULL,
  `GEIND_PLT` varchar(4) NOT NULL,
  `GEIND_PLT_NAME` varchar(30) NOT NULL,
  `SUPPL_DEPO` varchar(4) NOT NULL,
  `SUPPL_DEPO_NAME` varchar(30) NOT NULL,
  `WAERK` varchar(5) NOT NULL,
  `RENT` decimal(14,3) NOT NULL,
  `RAKEDEMCHRG` decimal(16,3) NOT NULL,
  `LDISTANCE` decimal(7,2) NOT NULL,
  `LDISTANCE_CLK` decimal(7,2) NOT NULL,
  `MATNR` varchar(18) NOT NULL,
  `VTEXT` varchar(20) NOT NULL,
  `MATNR1` varchar(18) NOT NULL,
  `MAKTX` varchar(40) NOT NULL,
  `INCURREDCOST` decimal(14,3) NOT NULL,
  `UNINCURREDCOST` decimal(14,3) NOT NULL,
  `SH_REGIO` varchar(3) NOT NULL,
  `SH_DSTRC` varchar(4) NOT NULL,
  `SH_BLOCK` varchar(7) NOT NULL,
  `SH_DESTINT` varchar(10) NOT NULL,
  `KALKS` varchar(1) NOT NULL,
  `DELIVERY_NO` varchar(10) NOT NULL,
  `TKNUM` varchar(10) NOT NULL,
  `MNFPLANT` varchar(4) NOT NULL,
  `MNFDESC` varchar(30) NOT NULL,
  `MVGR1` varchar(3) NOT NULL,
  `GROSSTURN` decimal(16,3) NOT NULL,
  `NETTURN` decimal(16,3) NOT NULL,
  `NAKEDREAL` decimal(16,3) NOT NULL,
  `TRANS_INCENTIVE` decimal(16,3) NOT NULL,
  `PLT_FRT` decimal(16,3) NOT NULL,
  `SP_REGIO` varchar(3) NOT NULL,
  `SP_DSTRC` varchar(4) NOT NULL,
  `SP_BLOCK` varchar(7) NOT NULL,
  `SP_DESTINT` varchar(10) NOT NULL,
  `TRAID` varchar(20) NOT NULL,
  `TRUCK_TYPE` varchar(20) NOT NULL,
  `EWB_NO` varchar(12) NOT NULL,
  `EDATE` varchar(10) NOT NULL,
  `EVDATE` varchar(10) NOT NULL,
  `STEUC` varchar(16) NOT NULL,
  `PAID_PRICE` decimal(12,3) NOT NULL,
  `KALKS_DESC` varchar(20) NOT NULL,
  `SP_REGIO_DESC` varchar(20) NOT NULL,
  `SP_DSTRC_DESC` varchar(20) NOT NULL,
  `SP_BLOCK_DESC` varchar(20) NOT NULL,
  `SP_DESTINT_DESC` varchar(20) NOT NULL,
  `MF_PLANT_TYPE` varchar(60) NOT NULL,
  `TOTAL_TDC_COST` decimal(14,3) NOT NULL,
  `TOTAL_DISTANCE` decimal(9,2) NOT NULL,
  `DEPOT_IND_FRIEGHT` decimal(16,3) NOT NULL,
  `TOTAL_INVOICE_FRT` decimal(14,3) NOT NULL,
  `ROAD_PF_INCURRED` decimal(14,3) NOT NULL,
  `ROAD_PF_UNINCURRED` decimal(14,3) NOT NULL,
  `ROAD_SF_INCURRED` decimal(14,3) NOT NULL,
  `ROAD_SF_UNINCURRED` decimal(14,3) NOT NULL,
  `RAIL_PF_INCURRED` decimal(14,3) NOT NULL,
  `RAIL_PF_UNINCURRED` decimal(14,3) NOT NULL,
  `DRDL_CHGS` decimal(9,3) NOT NULL,
  `DB_LAB_CHGS` decimal(9,3) NOT NULL,
  `ZINV_CANCEL` varchar(1) NOT NULL,
  `SH_DESTINT_DESC` varchar(20) NOT NULL,
  `SHIP_DISTANCE` decimal(13,3) NOT NULL,
  PRIMARY KEY (`ZSD_LCOST_DATA_SRV_PKID`),
  KEY `idx_zsd_lcost_data_srv_temp_VBELN` (`VBELN`)
) ENGINE=InnoDB AUTO_INCREMENT=23266 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  9:52:20
