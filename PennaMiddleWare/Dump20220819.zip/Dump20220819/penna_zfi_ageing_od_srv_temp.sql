-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: penna
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `zfi_ageing_od_srv_temp`
--

DROP TABLE IF EXISTS `zfi_ageing_od_srv_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `zfi_ageing_od_srv_temp` (
  `ZFI_AGEING_OD_SRV_Temp_PKID` int NOT NULL AUTO_INCREMENT,
  `Bukrs` varchar(4) NOT NULL,
  `Budat` varchar(10) NOT NULL,
  `Kunnr` varchar(10) NOT NULL,
  `Ktokd` varchar(4) NOT NULL,
  `Name1` varchar(35) NOT NULL,
  `Kunn2` varchar(10) NOT NULL,
  `Name2` varchar(35) NOT NULL,
  `Kunn3` varchar(10) NOT NULL,
  `Name3` varchar(35) NOT NULL,
  `Slab1` decimal(14,3) NOT NULL,
  `Slab2` decimal(14,3) NOT NULL,
  `Slab3` decimal(14,3) NOT NULL,
  `Slab4` decimal(14,3) NOT NULL,
  `Slab5` decimal(14,3) NOT NULL,
  `Slab6` decimal(14,3) NOT NULL,
  `Slab7` decimal(14,3) NOT NULL,
  `Slab8` decimal(14,3) NOT NULL,
  `Slab9` decimal(14,3) NOT NULL,
  `Waers` varchar(5) NOT NULL,
  `Regio` varchar(3) NOT NULL,
  `Dstrc` varchar(4) NOT NULL,
  `Dstxt` varchar(20) NOT NULL,
  `Regtxt` varchar(20) NOT NULL,
  `Zzzone` varchar(10) NOT NULL,
  `Zzbranch` varchar(4) NOT NULL,
  `Vkorg` varchar(4) NOT NULL,
  `Vkgrp` varchar(3) NOT NULL,
  `Vkbur` varchar(4) NOT NULL,
  `Zzbzirk` varchar(6) NOT NULL,
  `CreditLimit` decimal(14,3) NOT NULL,
  `AvailableCl` decimal(14,3) NOT NULL,
  `CreditPeriod` varchar(30) NOT NULL,
  `OsDays` varchar(2) NOT NULL,
  `OsAmt` decimal(14,3) NOT NULL,
  `OsOdAmt` decimal(14,3) NOT NULL,
  `OsOdDays` varchar(5) NOT NULL,
  `SecurityDep` decimal(14,3) NOT NULL,
  `ChqnrAmt` decimal(14,3) NOT NULL,
  `CurrFyOdOs` decimal(14,3) NOT NULL,
  `PreFyOdOs` decimal(14,3) NOT NULL,
  `PreFyClsOdOs` decimal(14,3) NOT NULL,
  `ActualOd` decimal(14,3) NOT NULL,
  PRIMARY KEY (`ZFI_AGEING_OD_SRV_Temp_PKID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  9:52:20
